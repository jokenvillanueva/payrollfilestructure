1. Copy the folder containing this document (payroll) to $APACHE_HOME/htdocs/payroll.
2. Create a new MySQL database schema named payroll. 
3. Create or select a database user that have access to the created schema.
4. Import the script sql/payroll.sql into the schema payroll.
5. Edit the file conf/configure.php
6. Replace hostname, dbuser and dbpassword with appropriate values.