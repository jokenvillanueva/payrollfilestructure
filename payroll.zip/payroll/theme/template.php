<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="description" content="">
 <meta name="author" content="">
 <meta name="application-name" content="">
 <meta name="msapplication-TileColor" content="#ffffff">
 <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
 <meta name="theme-color" content="#ffffff">
<title>US-Based Payroll System <?php echo $title; ?></title>


<!-- Custom styles for this template -->

  </style>
	
</head>

<body>


<!--Header-->

	<!-- Header -->

	
	<!-- Page Content -->



	<br /><br /><br /><br />
<!--End of Header-->
<div class="container">
<?php check_message(); ?>
<?php //require_once $content;?>
<h1>Welcome to payroll System</h1>
	<!--/row-->
	
	<hr>
	     <footer>
        <p>&copy; payroll </p>




        	
		   <script language="javascript" type="text/javascript">

		    </SCRIPT>		
      </footer>
</div>
<!--/.container-->
</body>
</html>